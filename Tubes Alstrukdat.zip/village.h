#ifndef village_H
#define village_H

#include "point.h"

typedef struct {
	POINT Lokasi;
	int Kepemilikan;
} Village;

#endif