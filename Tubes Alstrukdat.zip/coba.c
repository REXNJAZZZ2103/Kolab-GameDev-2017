#include "listsirkuler.h"
#include "unit.h"
#include <stdio.h>
#include "queue.h"

int main()
{
	Queue ListPlayer;

	BacaPlayer(&ListPlayer);
}