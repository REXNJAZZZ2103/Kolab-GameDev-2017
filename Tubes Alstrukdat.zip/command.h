#ifndef commandss_H
#define commandss_H

#include "map.h"
#include "listsirkuler.h"

void Move(MATRIKS *Map, List *L, Unit X) {
	
}

#endif