#ifndef _INCLUDE_ALL_H

#define _INCLUDE_ALL_H

#include "boolean.h"
#include "map.h"
#include "listsirkuler.h"
#include "matriks.h"
#include "unit.h"
#include "mesinkata.h"
#include "pcolor.h"
#include "queue.h"
#include "stackpoint.h"
#include "point.h"
#include "player.h"

#endif
